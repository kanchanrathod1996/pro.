<?php
  
namespace App\Http\Controllers\admin;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Session;
use App\Models\User;
use App\Models\Page;
use Hash;
  
class Dashboardcontoller extends Controller
{
    public function index(){
        return view('admin.dashboard');
   
    }



    public function indexes(){

        $pages = Page::get();
        return view('admin.page.index',compact('pages'));
  
    }

    public function  store(Request $request){

        
        request()->validate([
            'page_name' =>'required',
            'slug' =>'required',
      
           ]); 

           $page =new Page;
           $page->page_name = ($request->page_name);
           $page->slug = ($request->slug);
           $page->content = ($request->content);
           
           $page->save();

           return redirect('admin.page.index')->with('success','Category has been created successfully.');
           dd($request->all());
        }

    public function create(){


        return view('admin.page.create');
    
    }
    public function changeStatus(Request $request) {

        $data = $request->all();    
    
        $page = Page::find($data['id']);
    
        if ($page->status) {
            $page->status = 0;
        } else {
            $page->status = 1;
        }
    
        $page->save();
    
        $array = array();
        $array['status'] = $page->status;
        $array['success'] = true;
        $array['message'] = 'Status changed successfully!';
        echo json_encode($array);
    }

 public function destroy($id) {
    $page = Page::findOrFail($id);


    $page->destroy($id);
    $array = array();
    $array['success'] = true;
    $array['message'] = 'Userdata deleted successfully!';
    echo json_encode($array);

}
    

        public function logout()
        {
            Auth::guard('admin')->logout();
            Session::flush();
            Session::put('success', 'You are logout sucessfully');
            return redirect('admin/login');
        }
}