<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        
        <link href="assets/css/bootstrap5.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
        
        <title>task</title>
        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body>
        
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script src="assets/js/ajax.googleapis.com_ajax_libs_jquery_3.5.1_jquery.min.js"></script>
        <script src="assets/js/cdn.jsdelivr.net_npm_bootstrap@5.0.2_dist_js_bootstrap.bundle.min.js"></script>
        <script src="assets/js/code.jquery.com_ui_1.13.2_jquery-ui.js"></script>

        <script src="assets/js/cdnjs.cloudflare.com_ajax_libs_jquery-validate_1.20.0_jquery.validate.min.js"></script>
        <script src="assets/js/cdnjs.cloudflare.com_ajax_libs_jquery-validate_1.20.0_additional-methods.min.js"></script>
        
        <script src="assets/js/cdnjs.cloudflare.com_ajax_libs_script.js_2.0.2_script.min.js"></script>

        
        
        

        
        
        
        

        <script src="assets/js/numeric.js"></script>
        <script src="assets/js/common.js"></script>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
    
</html><?php /**PATH /home/mandar/web/www.gopi.com/resources/views/layouts/default.blade.php ENDPATH**/ ?>