<footer class="bg-body-tertiary text-center text-lg-start mt-5">
    <!-- Copyright -->
    <div class="text-center p-3 bg-dark text-white">
      © {!! date('Y') !!} Copyright : Task
    </div>
    <!-- Copyright -->
</footer>