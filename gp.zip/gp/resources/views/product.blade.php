@extends('layouts.default')
@section('content')  

<div class="card m-auto mt-5 shadow-lg border-0" style="width:60%">
    <div class="card-body">
        <h3 class="card-title text-center">Product Form</h3>
        @include('includes.notifications')
        <form class="text-center" method="post" action="{!! route('post-product') !!}">
            @csrf
            <div class="row mb-3 mt-3">
                <label class="col-sm-2 col-form-label">Product Name</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="product_name" name="product_name" value="{!! old('product_name') !!}">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">Rate</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control list-label" id="rate" name="rate" value="{!! old('rate') !!}">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">Unit</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control list-label" id="unit" name="unit" value="{!! old('unit') !!}">
                </div>
            </div>

            <a href="{!! url('/') !!}" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>

@endsection