<?php $__env->startSection('styles'); ?>
    <style>
        .list-label {
            border: 0;
            outline: 0;
            border-bottom: 2px solid #1718185e;
            font-size: 1rem;
            /* color: #ccc;         */
        }
        .form-control.list-label:focus{
            outline: 0;
            border-bottom: none;
        }

        a.remove{
            color: #df0b0b;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
    <?php echo $__env->make('includes.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card m-auto mt-5 shadow-lg border-0" style="width:60%">
        <div class="card-body">
            <h3 class="card-title text-center">Form</h3>
            <form class="text-center" method="post" action="<?php echo route('post-data'); ?>" id="customer-form">
                <?php echo csrf_field(); ?>
                <div class="row mb-3 mt-3">
                <label class="col-sm-2 col-form-label">Customer</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="customer" name="customer" autocomplete="off">
                </div>
                </div>
                <div class="row mb-3">
                <label for="inputPassword3" class="col-sm-2 col-form-label">Name Product</label>
                <div class="col-sm-9">
                    <select class="form-select" id="product" aria-label="Default select example" name="product_id">
                        <option value="">please select product</option>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo $k; ?>"><?php echo $v; ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Rate</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control list-label" id="rate" name="rate" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Unit</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control list-label" id="unit" name="unit" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Qty.</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control numberInput" name="qty" id="qty" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Discount(%)</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control numberInput" id="discount" name="discount" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Net Amount</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control list-label" id="net_amount" name="net_amount" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label">Total Amount</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control list-label" id="total_amount" name="total_amount" disabled>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary"><i class="bi bi-plus"></i>ADD</button>
            </form>
        </div>
    </div>
    <div class="card m-auto mt-5 shadow-lg border-0" style="width:70%">
        <div class="card-body">
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <th style="width: 20%">Product</th>
                        <th>Rate</th>
                        <th>Unit</th>
                        <th>Qty.</th>
                        <th>Disc%</th>
                        <th>Net Amt.</th>
                        <th>Total Amt.</th>
                        <th style="width: 10%">Action</th>
                    </tr>
                    <?php if(isset($customer)): ?>
                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo $k; ?>">
                        <td>
                            <select class="form-select" aria-label="Default select example" name="product_id" id="product1">
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo $key; ?>" <?php echo $key == $v['product_id'] ? 'selected' : ''; ?>><?php echo $value; ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td>
                            <input type="text" class="form-control list-label" id="rate1" name="rate" value="<?php echo isset($v['rate']) && $v['rate'] != '' ? $v['rate'] : ''; ?>" disabled>
                        </td>
                        <td>
                            <input type="text" class="form-control list-label" id="unit1" name="unit" value="<?php echo isset($v['unit']) && $v['unit'] != '' ? $v['unit'] : ''; ?>" disabled>
                        </td>
                        <td>
                            <input type="text" class="form-control numberInput" name="qty" id="qty1" value="<?php echo isset($v['qty']) && $v['qty'] != '' ? $v['qty'] : ''; ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control numberInput" name="discount" id="discount1" value="<?php echo isset($v['discount']) && $v['discount'] != '' ? $v['discount'] : ''; ?>">
                        </td>
                        <td>
                            <input type="text" class="form-control list-label" id="net_amount1" name="net_amount" value="<?php echo isset($v['net_amount']) && $v['net_amount'] != '' ? $v['net_amount'] : ''; ?>" disabled>
                        </td>
                        <td>
                            <input type="text" class="form-control list-label" id="total_amount1" name="total_amount" value="<?php echo isset($v['total_amount']) && $v['total_amount'] != '' ? $v['total_amount'] : ''; ?>" disabled>
                        </td>
                        <td>
                            <a class="remove" href="<?php echo url('remove-from-session/'.$k); ?>"><i class="bi bi-x bi-big"></i>remove</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td>No data Found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if(isset($customer)  && !empty($customer)): ?>
            <div class="text-end">
                <a href="<?php echo route('store-data'); ?>" class="btn btn-primary">SUBMIT</a>
            </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {

        $('#product').change(function() {
            var productId = $(this).val();
            if(productId != '') {
                $.ajax({
                    url: "<?php echo e(route('get-rateunit-by-productId')); ?>",
                    method: 'GET',
                    data: {id: productId },
                    success: function(response) {
                        $('#rate').val(response.rate);
                        $('#unit').val(response.unit);

                        var rate = $('#rate').val();
                        var qty = $('#qty').val();
                        var disc = $('#discount').val();

                        if(qty != '' && disc != ''){
                            var net_amt = rate-((rate*disc)/100);
                            $('#net_amount').val(net_amt);

                            var total_amt = net_amt*qty;
                            $('#total_amount').val(total_amt);                            
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            }
        });

        $('#qty').on('input',function() {
            var net_amt = $('#net_amount').val();
            var qty = $('#qty').val();

            if(net_amt != ''){
                var total_amt = net_amt*qty;
                $('#total_amount').val(total_amt);
            }
        });

        $('#discount').on('input',function() {
            var qty = $('#qty').val();
            var disc = $(this).val();
            var rate = $('#rate').val()

            var net_amt = rate-((rate*disc)/100);
            $('#net_amount').val(net_amt);

            if(qty != ''){
                var total_amt = net_amt*qty;
                $('#total_amount').val(total_amt);
            }
        });

        $('table').on('input', '.form-select', function () {
            var closestTr = $(this).closest('tr');
            var skey = closestTr.attr('id');
            var key = $(this).attr('name');
            var value = $(this).val();
            updateSession(skey,key,value);

        });

        $('table').on('input', '.form-control', function () {
            var closestTr = $(this).closest('tr');
            var skey = closestTr.attr('id');
            var key = $(this).attr('name');
            var value = $(this).val();
            updateSession(skey,key,value);
        });

    });

    function updateSession(skey,key,value) {
        $.ajax({
            url: "<?php echo e(route('update.session')); ?>",
            method: 'PATCH',
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                skey: skey,
                key: key,
                value: value
            },
            success: function (response) {
                
                var tr = document.getElementById(response.skey);
                var inputs = tr.querySelectorAll("input");

                inputs.forEach(function(input) {
                    // Check if the input has a specific name
                    if (input.name == "rate") {
                        input.value = response.rate;
                    }else if(input.name == "unit"){
                        input.value = response.unit;
                    }else if(input.name == "qty"){
                        input.value = response.qty;
                    }else if(input.name == "discount"){
                        input.value = response.discount;
                    }else if(input.name == "net_amount"){
                        input.value = response.net_amount;
                    }else if(input.name == "total_amount"){
                        input.value = response.total_amount;
                    }
                });
                // var tds = tr.querySelectorAll("td");

                // tds.forEach(function(td) {
                //     var input = td.querySelector("input");
                //     console.log(input.getAttribute("name"));
                // });
            },
            error: function (xhr) {
                console.error('Error updating session data');
                console.error(xhr);
            }
        });
    }

   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mandar/web/www.gopi.com/resources/views/index.blade.php ENDPATH**/ ?>