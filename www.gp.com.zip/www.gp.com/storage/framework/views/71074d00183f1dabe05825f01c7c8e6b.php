<footer class="bg-body-tertiary text-center text-lg-start mt-5">
    <!-- Copyright -->
    <div class="text-center p-3 bg-dark text-white">
      © <?php echo date('Y'); ?> Copyright : Task
    </div>
    <!-- Copyright -->
</footer><?php /**PATH /home/mandar/web/www.gopi.com/resources/views/includes/footer.blade.php ENDPATH**/ ?>