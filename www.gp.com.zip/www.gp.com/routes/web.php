<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\admin\Adminlogincontoller;
use App\Http\Controllers\admin\Dashboardcontoller;
use App\Http\Controllers\Front\Authcontroller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/clear-cache', function () {
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('view:clear');
    return 'Successfully clear the cache from system!!'; //Return anything
});



// Route::get('product', [HomeController::class, 'productView']);
// Route::post('product', [HomeController::class, 'postProduct'])->name('post-product');

// Route::get('/', [HomeController::class, 'index']);
// Route::get('get-rateunit-by-productId', [HomeController::class, 'getRateteUnitByProductId'])->name('get-rateunit-by-productId');
// Route::post('/', [HomeController::class, 'postData'])->name('post-data');
// // Route::get('store-data', [HomeController::class, 'storeData'])->name('store-data');
// Route::get('store-data', [HomeController::class, 'storeData'])->name('store-data');
// Route::get('remove-from-session/{key}', [HomeController::class, 'removeCustomerFromSession']);
// Route::patch('/update-session', [HomeController::class, 'update'])->name('update.session');
          




// this route is frontend side route

Route::group(['prefix' => 'front'],function(){
    route::group(['middleware' => 'guest'],function(){  
     

        Route::get('/login',[Authcontroller ::class, 'login'])->name('front.login');
        Route::post('/login',[Authcontroller ::class, 'authenticate'])->name('front.authenticate');
        Route::get('/register',[Authcontroller ::class, 'register'])->name('front.register');
        Route::post('/process-register',[Authcontroller ::class, 'processRegister'])->name('front.processRegister');
      

    });

    route::group(['middleware' => 'auth'],function(){

        Route::get('/profile',[Authcontroller ::class, 'profile'])->name('front.profile'); 
        Route::post('/update-profile',[Authcontroller ::class, 'updateProfile'])->name('front.updateprofile'); 
        Route::get('/order',[Authcontroller::class,'order'])->name('front.order');
  
        Route::get('/orderDetail{id}',[Authcontroller::class,'orderDetail'])->name('front.orderDetail');
        Route::get('/my-wishlist',[Authcontroller ::class, 'wishlist'])->name('front.wishlist'); 
        Route::post('/remove-Product-From-Wishlist',[Authcontroller ::class, 'removeProductFromWishlist'])->name('front.removeProductFromWishlist'); 
        
        Route::get('/logout',[Authcontroller ::class, 'logout'])->name('front.logout'); 
        

    });

});



// this route is admin side(backend)
Route::group(['prefix' => 'admin'],function(){
    
    route::group(['middleware' => 'admin.guest'],function(){
       
         Route::get('/login', [Adminlogincontoller::class, 'index'])->name('admin.login');
         Route::post('/login', [Adminlogincontoller::class, 'authenticate'])->name('admin.authenticate');
    });

    route::group(['middleware' => 'admin.auth'],function(){

        Route::get('/dashboard', [Dashboardcontoller::class, 'index'])->name('admin.dashboard');
        Route::get('/logout', [Dashboardcontoller::class, 'logout'])->name('admin.logout');



    });


});

