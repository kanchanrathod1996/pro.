@if (count($errors->all()) > 0)
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Error!</strong>
    <ul>
        @foreach($errors->all() as $message)
        <li>{{ $message }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if ($message = Session::get('success_message'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong>
    @if(is_array($message))
    @foreach ($message as $m)
    {{ $m }}
    @endforeach
    @else
    {{ $message }}
    @endif
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if ($message = Session::get('error_message'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Error!</strong>
    @if(is_array($message))
    @foreach ($message as $m)
    {{ $m }}
    @endforeach
    @else
    {{ $message }}
    @endif
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if ($message = Session::get('warning_message'))
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <strong>Warning!</strong>
    @if(is_array($message))
    @foreach ($message as $m)
    {{ $m }}
    @endforeach
    @else
    {{ $message }}
    @endif
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if ($message = Session::get('info_message'))
<div class="alert alert-info alert-dismissible fade show" role="alert">
    <strong>Info!</strong>
    @if(is_array($message))
    @foreach ($message as $m)
    {{ $m }}
    @endforeach
    @else
    {{ $message }}
    @endif
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

<!--ajax response message-->
<div class="alert alert-danger alert-dismissible fade show" style="display:none;">
    <i class="bi bi-exclamation-triangle me-1"></i>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <span class="msg-content"></span>
</div>
<div class="alert alert-success alert-dismissible fade show" style="display:none;">
    <i class="bi bi-check-circle me-1"></i>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <span class="msg-content"></span>   
</div>
<div class="alert alert-info alert-dismissible fade show" style="display:none;">
    <i class="bi bi-info-circle me-1"></i>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <span class="msg-content"></span>
</div>
<div class="alert alert-warning alert-dismissible fade show" style="display:none;">
    <i class="bi bi-exclamation-triangle me-1"></i>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    <span class="msg-content"></span>
</div>

