<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;
use Validator;
use App\Models\ProductMaster;
use App\Models\InvoiceMaster;
use App\Models\InvoiceDetail;

class HomeController extends Controller
{
    public function productView(){
        return view('product');
    }

    public function postProduct(Request $request){
        $data = $request->all();

        $rules = array(
            'product_name' => 'required',
            'rate' => 'required|numeric',
            'unit' => 'required',
        );

        $validator = Validator::make($data, $rules);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        ProductMaster::create($data);

        return redirect()->back()->with('success_message',"product add successfully");
    }

    public function index(){
        $customer = Session::get('customer') != null ? Session::get('customer') : array();
        $product = ProductMaster::pluck('product_name','product_id');

        return view('index',compact('customer','product'));
    }

    public function getRateteUnitByProductId(Request $request){

        $id = $request->id;

        $product = ProductMaster::where('product_id',$id)->first();

        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }

        return response()->json([
            'rate' => $product->rate,
            'unit' => $product->unit,
        ]);

    }

    public function postData(Request $request){
        $data = $request->all();

        $product = ProductMaster::where('product_id',$data['product_id'])->first();
        if (isset($product) && $product != '' && $data['customer'] != '' && $data['qty'] != '' && $data['discount'] != '' ) {
            
            $rate = $product->rate;
            $unit = $product->unit;

            $qty = $data['qty'];
            $discount = $data['discount'];

            $net_amount = $rate-(($rate*$discount)/100);
            $total_amount = $net_amount*$qty;

            $data['rate'] = $rate;
            $data['unit'] = $unit;
            $data['net_amount'] = $net_amount;
            $data['total_amount'] = $total_amount;

            Session::push('customer',$data);
        }

        return redirect()->back();
    }

    public function removeCustomerFromSession($key){
        Session::forget('customer.' . $key);
        return redirect('/');
    }

    public function update(Request $request){

        $data = $request->all();

        $skey = $data['skey'];
        $key = $data['key'];
        $value = $data['value'];

        $customer = Session::get('customer.' . $skey);

        if (array_key_exists($key, $customer)) {
            $customer[$key] = $value;

            if($key == "product_id"){

                $product = ProductMaster::where('product_id',$value)->first();
                $rate = $product->rate;
                $unit = $product->unit;

                $qty = $customer['qty'];
                $discount = $customer['discount'];

                $net_amount = $rate-(($rate*$discount)/100);
                $total_amount = $net_amount*$qty; 

                $customer['rate'] = $rate;
                $customer['unit'] = $unit;
                $customer['net_amount'] = $net_amount;
                $customer['total_amount'] = $total_amount;

            }elseif($key == "qty"){
                
                $net_amt = (int)$customer['net_amount'];
                $quen = (int)$customer['qty'];
                $customer['total_amount'] = $net_amt*$quen;

            }elseif($key == "discount"){

                $disc = (int)$customer['discount'];
                $rt = (int)$customer['rate'];
                $net_amnt = $rt-(($rt*$disc)/100);
                $total_amount = $net_amnt*(int)$customer['qty'];

                $customer['net_amount'] = $net_amnt;
                $customer['total_amount'] = $total_amount;
            }

            Session::put('customer.'.$data['skey'], $customer);

            return response()->json([
                'skey' => $skey,
                'prosuct_id' => $customer['product_id'],
                'qty' => $customer['qty'],
                'discount' => $customer['discount'],
                'rate' => $customer['rate'],
                'unit' => $customer['unit'],
                'net_amount' => $customer['net_amount'],
                'total_amount' => $customer['total_amount']
            ]);
        }
    }

    public function storeData(){
        $session = Session::get('customer');
        if($session != ''){
            foreach($session as $k=>$v){
                $invoice_master = InvoiceMaster::create([
                    'invoice_date' => date('Y-m-d H:i:s'),
                    'customer_name' => $v['customer'],
                    'total_amount' => $v['total_amount']
                ]);

                $invoice_id =  $invoice_master->id;

                InvoiceDetail::create([
                    'invoice_id' => $invoice_id,
                    'product_id' => $v['product_id'],
                    'rate' => $v['rate'],
                    'unit' => $v['unit'],
                    'qty' => $v['qty'],
                    'disc_percentage' => $v['discount'],
                    'net_amount' => $v['net_amount'],
                    'total_amount' => $v['total_amount'],
                ]);
            }
            Session::forget('customer');

            return redirect('/')->with('success_message','data updated succesfully');
        }else{
            return redirect('/')->with("error_message","some thing wen't wrong");
        }
    }
}

