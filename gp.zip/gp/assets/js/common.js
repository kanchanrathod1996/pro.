$(function() {
  $(".numberInput").forceNumeric(); // for number input for force enter numeric
    // Initialize form validation on the registration form.
    // It has the name attribute "registration"
    $("#customer-form").validate({
      // Specify validation rules
      rules: {
        // The key name on the left side is the name attribute
        // of an input field. Validation rules are defined
        // on the right side
        customer: {
            required :true,
        },
        product_id: {
          required: true,
        },
        qty: {
          required: true,
          
        },
        discount: {
          required: true,
        }
      },
      errorElement: 'span',
      errorPlacement: function (error, element) {
          
          if (element.attr("name") == "whatsapp") {
              error.insertAfter(".wa-opt");
          }else if (element.attr("name") == "agree") {
              error.insertAfter(".ag-opt");
          }else if (element.attr("name") == "tel_number_code") {
              error.insertAfter(".select2-container--default");
          } else {
              error.addClass('invalid-feedback');
              element.closest('.row').append(error);
          }
      },
      highlight: function (element, errorClass, validClass) {
          $(element).addClass('is-invalid');
      },
      unhighlight: function (element, errorClass, validClass) {
          $(element).removeClass('is-invalid');
      }
    });
 
  });
  