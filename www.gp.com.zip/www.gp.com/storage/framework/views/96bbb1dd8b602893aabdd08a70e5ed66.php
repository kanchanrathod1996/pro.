<?php $__env->startSection('content'); ?>  

<div class="card m-auto mt-5 shadow-lg border-0" style="width:60%">
    <div class="card-body">
        <h3 class="card-title text-center">Product Form</h3>
        <?php echo $__env->make('includes.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form class="text-center" method="post" action="<?php echo route('post-product'); ?>">
            <?php echo csrf_field(); ?>
            <div class="row mb-3 mt-3">
                <label class="col-sm-2 col-form-label">Product Name</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="product_name" name="product_name" value="<?php echo old('product_name'); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">Rate</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control list-label" id="rate" name="rate" value="<?php echo old('rate'); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">Unit</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control list-label" id="unit" name="unit" value="<?php echo old('unit'); ?>">
                </div>
            </div>

            <a href="<?php echo url('/'); ?>" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mandar/web/www.gopi.com/resources/views/product.blade.php ENDPATH**/ ?>